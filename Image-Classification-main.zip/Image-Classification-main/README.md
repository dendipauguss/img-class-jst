# Image-Classification
This Machine learning Image classification uses scikit-learn SVM image classification algorithm.
Open the google collab file and follow all the steps. You can classify any category images.
Here i have used Cars, Ice cream cone and Cricket ball images for classification, but you can use any category images to classify, all the steps are mentioned in the google collab file.
Cars , Ice cream cone and Cricket ball images are shared in this github repository.
